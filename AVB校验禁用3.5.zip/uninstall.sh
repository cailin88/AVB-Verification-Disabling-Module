#!/system/bin/sh

# AVB 隐形模块卸载脚本
MODDIR=${0%/*}
STEALTH_DIR="/data/adb/avb_stealth"
BACKUP_DIR="/data/adb/avb_backup"
RECOVERY_DIR="/data/adb/avb_recovery"

# 清理模块
cleanup_module() {
    echo "[UNINSTALL] 清理 AVB 隐形模块..."
    
    # 恢复原始属性
    resetprop ro.boot.verifiedbootstate green
    resetprop ro.boot.veritymode enforcing
    resetprop ro.boot.vbmeta.device_state locked
    
    # 清除模块属性
    resetprop --delete ro.stealth.avb_disabled
    resetprop --delete ro.stealth.verity_disabled
    
    # 清理init hook
    if [ -f "/dev/avb_hook.rc" ]; then
        rm -f /dev/avb_hook.rc
    fi
    
    # 清理init.rc中的注入
    if [ -f "/system/etc/init/hw/init.rc" ]; then
        sed -i '/import \/dev\/avb_hook.rc/d' /system/etc/init/hw/init.rc
    fi
    
    # 清理模块目录
    rm -rf "$STEALTH_DIR"
    
    echo "[UNINSTALL] 模块清理完成"
}

# 保留备份文件（可选）
# rm -rf "$BACKUP_DIR"
# rm -rf "$RECOVERY_DIR"

# 执行清理
cleanup_module

exit 0