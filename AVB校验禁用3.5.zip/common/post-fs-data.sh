#!/system/bin/sh

# AVB 隐形模块 - 核心Hook
MODDIR=${0%/*}
STEALTH_DIR="/data/adb/avb_stealth"
LOG_FILE="$STEALTH_DIR/stealth.log"
BACKUP_DIR="/data/adb/avb_backup"
RECOVERY_DIR="/data/adb/avb_recovery"

# 创建日志目录
mkdir -p "$STEALTH_DIR"
mkdir -p "$BACKUP_DIR"
mkdir -p "$RECOVERY_DIR"
chmod 700 "$STEALTH_DIR" "$BACKUP_DIR" "$RECOVERY_DIR"
echo "[$(date)] 启动AVB隐形模块" > "$LOG_FILE"

# 启动时检查恢复需求
check_recovery_on_boot() {
    if [ -f "$STEALTH_DIR/recovery_triggered" ]; then
        echo "[RECOVERY] 检测到恢复需求，启动恢复流程" >> "$LOG_FILE"
        nohup /system/bin/avb_recovery >"$RECOVERY_DIR/recovery.log" 2>&1 &
        return 1
    fi
    
    # 检查启动失败计数
    local fail_count=0
    if [ -f "$STEALTH_DIR/boot_fail_count" ]; then
        fail_count=$(cat "$STEALTH_DIR/boot_fail_count")
    fi
    
    if [ $fail_count -ge 5 ]; then
        echo "[RECOVERY] 启动失败次数超过限制，触发恢复" >> "$LOG_FILE"
        touch "$STEALTH_DIR/recovery_triggered"
        nohup /system/bin/avb_recovery >"$RECOVERY_DIR/recovery.log" 2>&1 &
        return 1
    fi
    
    return 0
}

# 加载欺骗配置
load_stealth_config() {
    if [ -f "$MODDIR/system/etc/stealth_props.conf" ]; then
        while read -r prop; do
            [ -z "$prop" ] || resetprop --delete "$prop"
        done < "$MODDIR/system/etc/stealth_props.conf"
    fi
}

# 关键欺骗属性
set_stealth_properties() {
    resetprop ro.boot.verifiedbootstate green
    resetprop ro.boot.veritymode enforcing
    resetprop ro.boot.vbmeta.device_state locked
    resetprop ro.boot.flash.locked 1
    
    # 设置隐藏属性
    resetprop ro.stealth.avb_disabled 1
    resetprop ro.stealth.verity_disabled 1
}

# 注入init hook
inject_init_hook() {
    if [ -f "$MODDIR/common/system_hook/avb_hook.rc" ]; then
        cp "$MODDIR/common/system_hook/avb_hook.rc" /dev/avb_hook.rc
        chmod 644 /dev/avb_hook.rc
        
        # 检查是否已注入
        if ! grep -q "import /dev/avb_hook.rc" /system/etc/init/hw/init.rc 2>/dev/null; then
            echo "import /dev/avb_hook.rc" >> /system/etc/init/hw/init.rc
        fi
    fi
}

# 启动诊断守护进程
start_diagnostic_daemon() {
    nohup "$MODDIR/system/bin/diag_system" >"$STEALTH_DIR/diag.log" 2>&1 &
}

# 启动隐形守护进程
start_stealth_daemon() {
    nohup "$MODDIR/system/bin/avb_stealthd" >"$STEALTH_DIR/stealthd.log" 2>&1 &
}

# 主初始化流程
main_init() {
    # 检查恢复需求
    if ! check_recovery_on_boot; then
        return 1
    fi
    
    # 加载配置
    load_stealth_config
    
    # 设置欺骗属性
    set_stealth_properties
    
    # 注入init hook
    inject_init_hook
    
    # 启动守护进程
    start_diagnostic_daemon
    start_stealth_daemon
    
    echo "[$(date)] 模块初始化完成" >> "$LOG_FILE"
    return 0
}

# 执行主初始化
main_init

exit 0