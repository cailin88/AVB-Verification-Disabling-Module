#!/system/bin/sh

# AVB 隐形模块服务脚本
MODDIR=${0%/*}
STEALTH_DIR="/data/adb/avb_stealth"
LOG_FILE="$STEALTH_DIR/service.log"

# 等待系统启动完成
until [ "$(getprop sys.boot_completed)" -eq 1 ]; do
    sleep 1
done

# 系统启动完成后重置启动计数
echo 0 > "$STEALTH_DIR/boot_fail_count"
rm -f "$STEALTH_DIR/recovery_triggered"

# 检查是否需要因音量键禁用模块
check_volume_disable() {
    if [ -f "$STEALTH_DIR/volume_disable" ]; then
        echo "[SERVICE] 模块因音量键被禁用" >> "$LOG_FILE"
        touch "$MODDIR/disable"
        rm -f "$STEALTH_DIR/volume_disable"
    fi
}

# 启动安全监控后台服务
start_safety_monitor() {
    nohup /system/bin/avb_stealthd --monitor >"$STEALTH_DIR/monitor.log" 2>&1 &
}

# 主服务逻辑
main_service() {
    echo "[$(date)] 启动服务脚本" > "$LOG_FILE"
    
    # 检查音量键禁用
    check_volume_disable
    
    # 启动安全监控
    start_safety_monitor
    
    echo "[$(date)] 服务脚本完成" >> "$LOG_FILE"
}

# 执行主服务
main_service

exit 0